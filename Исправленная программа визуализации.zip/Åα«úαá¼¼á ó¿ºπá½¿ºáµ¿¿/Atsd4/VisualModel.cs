﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Text.RegularExpressions;
using System.Windows.Threading;

namespace Atsd4
{
    public class VisualModel {
        public ManualResetEventSlim MutexOne { set; get; }
        Border MovedVertice { set; get; }
        Point PreviewPos { set; get; }
        public Canvas Vertices { set; get; }
        public Canvas Vertexes { set; get; }

        public List<List<int>> PrevVersion { set; get; }
        public Graph GR { set; get; }

        public RadioButton AddVerticeParametr { set; get; }
        public RadioButton DeleteParam { set; get; }
        public RadioButton MoveParam { set; get; }
        public RadioButton Start { get; set; }
        public RadioButton Finish { get; set; }
        public ListBox dArr { set; get; }

        SolidColorBrush poin = new SolidColorBrush(new Color() { A = 255, R = 40, G = 130, B = 40 }) { Opacity = 100 };
        SolidColorBrush vvv = new SolidColorBrush(new Color() { A = 255, B = 195, G = 50, R = 195 }) { Opacity = 95 };
        SolidColorBrush MarkedVVV = new SolidColorBrush(new Color() { A = 255, R = 240, G = 150, B = 23 }) { Opacity = 100 };
        SolidColorBrush MarkedHead = new SolidColorBrush(new Color() { A = 255, R = 240, G = 200, B = 23 }) { Opacity = 100 };
        double VerticeRadius = 25;

        public Dictionary<string, int> VertexNumerator { set; get; } = new Dictionary<string, int>();

        public Grid FirstPoint { set; get; }

        public Grid FinishPoint { set; get; }
        private Grid WorkedVertex { set; get; }
        private int deikstraMarkPrev { set; get; } = -1;
        int TopElem { set; get; }
        bool IsMoveVertice = false;
        bool IsMoveVertex = false;
        public VisualModel(Canvas vertex, Canvas vertice, Graph gr) {
            Vertices = vertice;
            Vertexes = vertex;

            GR = gr;

        }

        public void MarkingDeikstra(int NextMark) {

            if (deikstraMarkPrev == -1) {
                (FirstPoint.Children[2] as TextBlock).Text = "0";

            }
            if (GR.DeikstraNextPos[NextMark] != -1)
                (((Vertices.Children[GR.DeikstraNextPos[NextMark]] as Border).Child as Grid).Children[0] as Ellipse).Fill = Brushes.Red;
            if (deikstraMarkPrev != -1) {
                (((Vertices.Children[deikstraMarkPrev] as Border).Child as Grid).Children[0] as Ellipse).Fill = poin;
                deikstraMarkPrev = GR.DeikstraNextPos[NextMark];
            }

            for (int i = 0; i < GR.DeikstraMarks[NextMark].Count; i++) {
                var graph = GR.DeikstraMarks[NextMark][i];
                var src = graph[0];
                var val = graph[1];
                var obj = Vertices.Children[src];
                var grd = (obj as Border).Child as Grid;
                (grd.Children[2] as TextBlock).Text = $"{val}";
                var key = (GR.DeikstraNextPos[(NextMark > 0) ? NextMark - 1 : 0] < src) ? $"{ GR.DeikstraNextPos[(NextMark > 0) ? NextMark - 1 : 0]}-{src}" : $"{ src}-{GR.DeikstraNextPos[(NextMark > 0) ? NextMark - 1 : 0]}";
                if (VertexNumerator.TryGetValue(key, out int l))
                    ((Vertexes.Children[l] as Grid).Children[0] as Path).Stroke = MarkedVVV;
            }


        }
        public void MarkingFind(int pos, int prev = 0, int auto = 0) {

            if (pos < 0 || GR.MarkingStep.Count <= pos)
                return;

            Vertices.Dispatcher.Invoke(new Action(() => {
                if (PrevVersion == null && prev == 0) {
                    PrevVersion = new List<List<int>>();
                    PrevVersion.Add(new List<int>());
                    for (int i = 0; i < Vertices.Children.Count; ++i) {
                        PrevVersion[0].Add(-1);
                    }
                    PrevVersion[0][Convert.ToInt32((FirstPoint.Children[1] as TextBlock).Text)] = 0;
                }
            }));
            dArr.Dispatcher.Invoke(new Action(() => {
                dArr.Items.Clear();
                var getPos = GR.topp;
                for (int i = 0; i < PrevVersion[pos].Count; ++i) {
                    int natural = getPos[i];
                    var stack = new StackPanel() { Width = 40, Background = Brushes.SeaShell};
                    stack.Children.Add(new TextBlock() { Margin = new Thickness(0, 0, 0, 20), FontSize = 30, Text = $"{natural}" });
                    stack.Children.Add(new TextBlock() { FontSize = 30, Text = $"{PrevVersion[pos][natural]}" });
                    dArr.Items.Add(stack);
                }

            }));
            var novVer = GoBack(pos, PrevVersion[pos]);
            
            if (pos + 1 == PrevVersion.Count)
               PrevVersion.Add(novVer);
            if (auto == 0) {
                Thread.Sleep(800);
                MutexOne.Wait(Timeout.Infinite);
            }
                
        }
        public List<int> GoBack(int pos,  List<int> vers) {
            (Vertexes.Parent as Canvas).Dispatcher.Invoke(new Action(() => {
                for (int i = 0; i < Vertexes.Children.Count; i++) {
                    var param = (Vertexes.Children[i] as Grid).Children[0] as Path;
                    param.Stroke = vvv;
                }
                var getPos = GR.TopPoints;
                for (int i = 0; i < Vertices.Children.Count; ++i) {
                    (((Vertices.Children[i] as Border).Child as Grid).Children[2] as TextBlock).Text =
                        (vers[i] != -1 && vers[i] != 100000) ? $"{vers[i]}" : "INF";
                    tryColoring(i, poin);
                    int natural = GR.topp[i];
                    ((dArr.Items[i] as StackPanel).Children[1] as TextBlock).Text = (vers[natural] != -1 && vers[natural] != 100000) ? $"{vers[natural]}" : "INF";
                    ((dArr.Items[i] as StackPanel).Children[0] as TextBlock).Background = Brushes.Transparent;
                    ((dArr.Items[i] as StackPanel).Children[1] as TextBlock).Background = Brushes.Transparent;
                }
                int to = GR.MarkingStep[pos][0][0];
                
                for (int i = 1; i < GR.MarkingStep[pos].Count; ++i) {
                    var a = GR.MarkingStep[pos][i];
                    int src = a[0];
                    vers[src] = a[1];
                    int nat = GR.topp[src];
                    (((Vertices.Children[src] as Border).Child as Grid).Children[2] as TextBlock).Text =
                       (vers[src] != -1 && vers[src] != 100000) ? $"{vers[src]}" : "INF";
                    ((dArr.Items[getPos[src]] as StackPanel).Children[1] as TextBlock).Text = (vers[src] != -1 && vers[src] != 100000) ? $"{vers[src]}" : "INF"; ;

                    ((dArr.Items[getPos[src]] as StackPanel).Children[1] as TextBlock).Background = Brushes.Red;
                    tryColoring(src, Brushes.Red);
                    if (VertexNumerator.TryGetValue($"{Math.Min(to, src)}-{Math.Max(to, src)}", out int j)) {
                        ((Vertexes.Children[j] as Grid).Children[0] as Path).Stroke = MarkedVVV;
                    }
                }

                ((dArr.Items[getPos[to]] as StackPanel).Children[0] as TextBlock).Background = MarkedHead;
                tryColoring(to, MarkedHead);
                
            }));

            return vers;

        }
        void tryColoring (int point, SolidColorBrush a) {
            var col = (((Vertices.Children[point] as Border).Child as Grid).Children[0] as Ellipse).Fill;
            if ( (col == Brushes.Red || col == MarkedHead || col == poin)) {
                (((Vertices.Children[point] as Border).Child as Grid).Children[0] as Ellipse).Fill = a;
            }
            
            
        }
        public void AddVertice(int index, Point pos)
        {
            if (index < Vertices.Children.Count)
                Vertices.Children.RemoveAt(index);
            Grid El = new Grid() { Width = VerticeRadius * 3, Height = VerticeRadius * 3, Background = Brushes.Transparent, HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center };
            El.Children.Add(new Ellipse() {Height = VerticeRadius * 2, Width = VerticeRadius * 2, Fill = poin, HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center });
            var num = new TextBlock() { Text = $"{index}", Foreground = Brushes.WhiteSmoke,FontSize = 15, FontWeight = FontWeights.Bold, HorizontalAlignment = HorizontalAlignment.Center, Margin = new Thickness(0, VerticeRadius / 1.5, 0, 0), Width = VerticeRadius * 3, Height = VerticeRadius* 3, TextAlignment = TextAlignment.Center, Background = Brushes.Transparent };
            num.SetValue(Canvas.ZIndexProperty, 1);
            El.Children.Add(num);
            var match = new TextBlock() { Text = "INF", Foreground = Brushes.DarkRed, Height = VerticeRadius / 1.5, HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0, VerticeRadius / 3,0,0)};
            El.Children.Add(match);
            El.SetValue(Canvas.LeftProperty, pos.X -VerticeRadius);
            El.SetValue(Canvas.TopProperty, pos.Y - VerticeRadius);
            
            Border b = new Border() { CornerRadius = new CornerRadius(VerticeRadius* 3), Child = El, Width = VerticeRadius * 3, Height = VerticeRadius * 3, Background = Brushes.Transparent};
            b.SetValue(Canvas.LeftProperty, pos.X - VerticeRadius * 1.5);
            b.SetValue(Canvas.TopProperty, pos.Y - VerticeRadius * 1.5);
            b.DataContext = pos;
            Vertices.Children.Insert(index, b);
            b.MouseEnter += Vertice_MouseEnter;
            b.MouseLeave += Vertice_MouseLeave;
        }

        private void Vertice_MouseLeave(object sender, MouseEventArgs e)
        {
            if (DeleteParam.IsChecked == true)
                (sender as Border).Background = Brushes.Transparent;
        }

        private void Vertice_MouseEnter(object sender, MouseEventArgs e)
        {
            if (DeleteParam.IsChecked == true) 
            {
                (sender as Border).Background = new SolidColorBrush(new Color() { R = 200, G = 20, B = 20, A = 80 }) {Opacity = 100};
                
            }
        }

        public void Vertice_FinishMove(object sender, MouseButtonEventArgs e)
        {

            if (IsMoveVertice != false)
            {
                if (IsCrossed(e.GetPosition(Vertices)) >= 0)
                {
                    MovedVertice.SetValue(Canvas.LeftProperty, PreviewPos.X);
                    MovedVertice.SetValue(Canvas.TopProperty, PreviewPos.Y);
                    MovedVertice.Background = Brushes.Transparent;
                    
                    MovedVertice.DataContext = null;
                    MovedVertice.DataContext = new Point((double)MovedVertice.GetValue(Canvas.LeftProperty) + VerticeRadius, (double)MovedVertice.GetValue(Canvas.TopProperty) + VerticeRadius);
                    PreviewPos = new Point(PreviewPos.X + VerticeRadius * 1.5, PreviewPos.Y + VerticeRadius * 1.5);
                    BalanceVertex(e.Source as TextBlock, PreviewPos);
                    PreviewPos = new Point(-10, -10);
                }
                else
                {
                    MovedVertice.DataContext = null;
                    MovedVertice.DataContext = new Point((double)MovedVertice.GetValue(Canvas.LeftProperty) + VerticeRadius * 1.5, (double)MovedVertice.GetValue(Canvas.TopProperty) + VerticeRadius * 1.5);
                    MovedVertice = null;
                    
                }

            }
            IsMoveVertice = false;
        }
        
        public void Vertice_Moving(object sender, MouseEventArgs e)
        {
            if (IsMoveVertice)
            {
                Point pos = e.GetPosition(Vertices);
                if (pos.X - 15 < 0 ||
                    pos.Y - 15 < 0 ||
                    pos.Y > (Vertices.Parent as Canvas).ActualHeight - 15 ||
                    pos.X > (Vertices.Parent as Canvas).ActualWidth - 15
                    )
                {
                    PreviewPos = pos;
                    return;
                }
                int redElem = IsCrossed(pos);
                (MovedVertice).Background = Brushes.Transparent;
                if (redElem > -1)
                    (MovedVertice).Background = new SolidColorBrush(new Color() {A = 90, R= 200, G = 20, B = 20 }) {Opacity = 90 };

                MovedVertice.SetValue(Canvas.LeftProperty, pos.X - VerticeRadius * 1.5);
                MovedVertice.SetValue(Canvas.TopProperty, pos.Y - VerticeRadius * 1.5);
                BalanceVertex(e.Source as TextBlock, pos);
            }
        }
        private int IsCrossed(Point pos)
        {
            for (int i = 0; i < Vertices.Children.Count; i++)
            {
                var Grid = (Vertices.Children[i] as Border).Child as Grid;
                if ((Grid.Children[1] as TextBlock).Text != ((MovedVertice.Child as Grid).Children[1] as TextBlock).Text)
                {
                    var posX = ((Point)(Vertices.Children[i] as Border).DataContext).X;
                    var posY = ((Point)(Vertices.Children[i] as Border).DataContext).Y;
                    var h = Grid.ActualHeight;
                    var w = Grid.ActualWidth;
                    if (Math.Sqrt((posX - pos.X) * (posX - pos.X) + (posY - pos.Y) * (posY - pos.Y)) <= VerticeRadius * 3)
                    {
                        return i;
                    }
                }

            }
            return -1;
        }

        public void Verice_StartMove(object sender, MouseButtonEventArgs e)
        {
            if (MoveParam.IsChecked == true && e.Source as TextBlock != null)
            {
                IsMoveVertice = true;
                MovedVertice = ((e.Source as TextBlock).Parent as Grid).Parent as Border;
                PreviewPos = new Point((double)MovedVertice.GetValue(Canvas.LeftProperty), (double)MovedVertice.GetValue(Canvas.TopProperty));
                MovedVertice.SetValue(Canvas.ZIndexProperty, 1);
                
            }
        }

        public void Vertice_Action(object sender, MouseButtonEventArgs e)
        {
            
            if ( AddVerticeParametr.IsChecked == true && e.Source as Canvas != null)
            {
                GR.AddElem(TopElem);
                AddVertice(TopElem++, e.GetPosition(Vertices));
                if (Vertices.Children.Count == 1)
                {
                    FirstPoint = (Vertices.Children[0] as Border).Child as Grid;
                    (FirstPoint.Children[0] as Ellipse).Fill = Brushes.DarkOrange;
                }
            }
            var p = e.Source as TextBlock;
            if (Start.IsChecked == true && p != null)
            {
                if (FirstPoint != null)
                    (FirstPoint.Children[0] as Ellipse).Fill = poin;
                if ((((p.Parent) as Grid).Children[0] as Ellipse).Fill == Brushes.BlueViolet) {
                    FinishPoint = null;
                }
                FirstPoint = (p.Parent as Grid);
                (FirstPoint.Children[0] as Ellipse).Fill = Brushes.DarkOrange;

                
            }
            else if (Finish.IsChecked == true && p != null) {
                if (FinishPoint != null)
                    (FinishPoint.Children[0] as Ellipse).Fill = poin;
                if ((((p.Parent) as Grid).Children[0] as Ellipse).Fill == Brushes.DarkOrange) {
                    FirstPoint = null;
                }
                FinishPoint = (p.Parent as Grid);
                (FinishPoint.Children[0] as Ellipse).Fill = Brushes.BlueViolet;
            }
        }

        private void RemoveVertice(int index)
        {
            GR.RemoveItem(index);
            Dictionary<string, int> copyDict = new Dictionary<string, int>();
            
            for (int i = 0; i < Vertexes.Children.Count; i++)
            {
                var param = (int[])(Vertexes.Children[i] as Grid).DataContext;
                if (param[0] == index || param[1] == index) {
                    int test = -1;
                    VertexNumerator.TryGetValue($"{param[0]}-{param[1]}", out test);
                    if (test != -1) {
                        VertexNumerator.Remove($"{param[0]}-{param[1]}");
                        test = -1;
                    }
                    VertexNumerator.TryGetValue($"{param[1]}-{param[0]}", out test);
                    if (test != -1) {
                        VertexNumerator.Remove($"{param[1]}-{param[0]}");
                    }
                    Vertexes.Children.RemoveAt(i);
                    List<string> keysFoRepair = new List<string>();
                    foreach (var aaa in VertexNumerator) {
                        if (aaa.Value >= i) {
                            keysFoRepair.Add(aaa.Key);
                        }
                    }
                    foreach (var key in keysFoRepair) {
                        --VertexNumerator[key];
                    }
                    --i;
                }
                
            }
            foreach (var aaa in VertexNumerator) {
                string[] keys = aaa.Key.Split('-');
                string newkey = "";
                int beg = Convert.ToInt32(keys[0]);
                int end = Convert.ToInt32(keys[1]);
                if (beg >= index) {
                    newkey += $"{--beg}-";
                }
                else {
                    newkey += $"{beg}-";
                }
                if (end >= index) {
                    newkey += $"{--end}";
                }
                else {
                    newkey += $"{end}";
                }
                copyDict.Add(newkey, aaa.Value);
            }
            VertexNumerator = copyDict;
            if (getColorFromBorder(index) == Brushes.BlueViolet) {
                FinishPoint = null;
            }
            if (getColorFromBorder(index) == Brushes.DarkOrange) {
                FirstPoint = null;
            }
            Vertices.Children.RemoveAt(index);
            TopElem--;
            RefreshVertice();
        }
        SolidColorBrush getColorFromBorder(int index) {
            return (((Vertices.Children[index] as Border).Child as Grid).Children[0] as Ellipse).Fill as SolidColorBrush;
        }
        public void RefreshVertice()
        {
            for(int i = 0; i < Vertices.Children.Count; i++)
            {
                string temp = (((Vertices.Children[i] as Border).Child as Grid).Children[1] as TextBlock).Text;
                if(temp != $"{i}")
                {

                    foreach (var obj in Vertexes.Children)
                    {
                        var dcon = (obj as Grid).DataContext as int[];
                        if (dcon[0] == i + 1)
                            dcon[0] = i;
                        if (dcon[1] == i + 1)
                            dcon[1] = i;
                    }
                    
                    (((Vertices.Children[i] as Border).Child as Grid).Children[1] as TextBlock).Text = $"{i}";
                    
                }
                tryColoring(i, poin);
                if (dArr.HasItems) {
                    ((dArr.Items[i] as StackPanel).Children[0] as TextBlock).Background = Brushes.Transparent;
                    ((dArr.Items[i] as StackPanel).Children[1] as TextBlock).Background = Brushes.Transparent;
                }
                
                (((Vertices.Children[i] as Border).Child as Grid).Children[2] as TextBlock).Text = "INF";
            }
            for (int i = 0; i < Vertexes.Children.Count; i++) {
                var param = (Vertexes.Children[i] as Grid).Children[0] as Path;
                param.Stroke = vvv;
            }
        }
        public void Clear_Smth(object sender, MouseButtonEventArgs e)
        {
            if(DeleteParam.IsChecked == true)
            {
                if(e.OriginalSource as TextBlock != null)
                    RemoveVertice(Convert.ToInt32((e.OriginalSource as TextBlock).Text));
                if(e.OriginalSource as Grid != null && (e.OriginalSource as Grid).DataContext as int[] == null)
                {
                    RemoveVertice(Convert.ToInt32(((e.OriginalSource as Grid).Children[1] as TextBlock).Text));
                }
                if (e.OriginalSource as TextBox != null || e.OriginalSource as Path != null)
                    Vertex_Del(e.OriginalSource);
               

            }
        }
        
        public void Vertex_Finish(object sender, MouseButtonEventArgs e)
        {
            if(IsMoveVertice == false && IsMoveVertex == true)
            {
                if (e.Source as TextBlock != null)
                {
                    int start = (WorkedVertex.DataContext as int[])[0];
                    int finish = Convert.ToInt32((e.Source as TextBlock).Text);
                    if (start != finish)
                    {
                        for (int i = 0; i < Vertexes.Children.Count; i++)
                        {
                            var test = (Vertexes.Children[i] as Grid).DataContext as int[];
                            if (test[0] == start && test[1] == start)
                                Vertexes.Children.RemoveAt(i);

                        }
                        bool[] visited = new bool[Vertices.Children.Count];
                        List<int> points = new List<int>();
                        GR.Dfs(finish, ref visited, ref points);
                        if (visited[start]) {
                            MessageBox.Show("Нельзя добавлять циклы","Предупреждение", MessageBoxButton.OK, MessageBoxImage.Asterisk);
                        } else {
                            AddVertex(start, finish);
                            GR.AddArrow(start, finish);
                        }
                        

                    }
                    else
                    {
                        Vertexes.Children.Remove(WorkedVertex);
                        WorkedVertex = null;
                    }
                }
                else
                {
                    Vertexes.Children.Remove(WorkedVertex);
                    WorkedVertex = null;
                }
                IsMoveVertex = false;
            }
        }
        public void Vertex_Start(object sender, MouseButtonEventArgs e)
        {
            if(e.Source as TextBlock != null)
            {
                var point = (Point)(((e.Source as TextBlock).Parent as Grid).Parent as Border).DataContext;
                int start = Convert.ToInt32((e.Source as TextBlock).Text);
                AddVertex(start, start, 0, e.GetPosition(Vertices));
                IsMoveVertex = true;
            }
        }
        public void Moving_Vertex(object sender, MouseEventArgs e)
        {
            if(IsMoveVertice == false && IsMoveVertex == true)
            {
                MovingVertex(e.GetPosition(Vertexes), WorkedVertex);
            }
        }
        public void MovingVertex(Point e, Grid WV, int head = 0, bool twoWay = false)
        {
            
            var startP = (Point)(Vertices.Children[(WV.DataContext as int[])[head]] as Border).DataContext;
            
            var vertex = new GeometryGroup();
            
            if(twoWay)
            {
                vertex.Children.Add(Arrow(startP.X, startP.Y, e.X, e.Y, 20, 9));
                vertex.Children.Add(Arrow(e.X, e.Y, startP.X, startP.Y, 20, 9));
            }
            else
            {
                if (head == 0)
                    vertex.Children.Add(Arrow(startP.X, startP.Y, e.X, e.Y, 20, 9));
                else
                    vertex.Children.Add(Arrow(e.X, e.Y, startP.X, startP.Y, 20, 9));
            }
               
            vertex.Children.Add(new LineGeometry(startP, e));

            (WV.Children[0] as Path).Data = vertex;
            (WV.Children[1] as TextBox).Margin = new Thickness((startP.X + e.X) / 2, Math.Abs(startP.Y + e.Y) / 2, 0, 0);
        }
        public void AddVertex(int start, int finish, int val = 0, Point move = new Point())
        {

            int TwoWay = -1;
            var posStart = ((Point)(Vertices.Children[start] as Border).DataContext);
            var posFinish = ((Point)(Vertices.Children[finish] as Border).DataContext);
            if(move  != default)
            {
                posFinish = move;
            }
            else
            for (int i = 0; i < Vertexes.Children.Count; i++)
            {
                var g = Vertexes.Children[i];
                var test = (g as Grid).DataContext as int[];
                if (test[0] == start && test[1] == finish)
                    return;
                if(test[1] == start && test[0] == finish)
                {
                    TwoWay = i;
                    break;
                }
            }
            
            var Arr = new GeometryGroup() {
                Children = new GeometryCollection() {
                    Arrow(
                        posStart.X,
                        posStart.Y,
                        posFinish.X,
                        posFinish.Y,
                        20,
                        9
                        )
                }
            };
            if (TwoWay >= 0)
            {
                var GRD = (Vertexes.Children[TwoWay] as Grid);
                var value = (GRD.DataContext as int[])[2];
                ((GRD.Children[0] as Path).Data as GeometryGroup).Children.Add(Arr);
                GR.AddArrow(start, finish, value);
            }
                
            else
            {
                Arr.Children.Add(new LineGeometry(new Point(posStart.X , posStart.Y ), new Point(posFinish.X , posFinish.Y )));
                var grd = new Grid() { DataContext = new int[] { start, finish, val } };
                var path = new Path() { Data = Arr, StrokeThickness = 3.5, Stroke = vvv };
                grd.Children.Add(path);

                var txt = new TextBox() {
                    Text = $"{val}",
                    Width = 30,
                    Height = 25,
                    FontSize = 14,
                    Margin = new Thickness((posFinish.X + posStart.X) / 2, Math.Abs(posFinish.Y + posStart.Y) / 2, 0, 0),
                    VerticalAlignment = VerticalAlignment.Top,
                    HorizontalAlignment = HorizontalAlignment.Left,
                    Background = vvv,
                    Foreground = Brushes.White
                };
                txt.SetValue(Canvas.ZIndexProperty, 3);
                txt.TextChanged += Txt_TextChanged;
                txt.GotMouseCapture += Txt_MouseDown;
                

                grd.Children.Add(txt);
                
                Vertexes.Children.Add(grd);
                WorkedVertex = grd;
                var min = 0;
                var max = 0;
                if( start != finish)
                {
                    if (start >= finish)
                    {
                        max = start;
                        min = finish;
                    }
                    else { max = finish; min = start; }
                    if (!VertexNumerator.TryGetValue($"{min}-{max}", out int aaaa))
                        VertexNumerator.Add($"{min}-{max}", Vertexes.Children.Count - 1);
                }
               
            }
            
        }

        private void Txt_MouseDown(object sender, RoutedEventArgs e) {
            (sender as TextBox).SelectAll();
        }

        private void Vertex_Del(object sender)
        {
            var smth2 = sender as Path;
            var par = (sender is TextBox smth) ? (smth.Parent as Grid).DataContext as int[] : (smth2.Parent as Grid).DataContext as int[];


            GR.RemoveArrow(par[0], par[1]);
            for(int i = 0; i < Vertexes.Children.Count; i++)
            {
                var test = (Vertexes.Children[i] as Grid).DataContext as int[];
                if((test[0] == par[0] && test[1] == par[1]) || (test[1] == par[0] && test[0] == par[1]))
                {
                    Vertexes.Children.RemoveAt(i);
                    VertexNumerator.Remove($"{Math.Min(test[0], test[1])}-{Math.Max(test[0], test[1])}");
                    break;
                }
            }
        }

        public void Txt_TextChanged(object sender, TextChangedEventArgs e)
        {
            var txbox = sender as TextBox;
            if (Regex.IsMatch(txbox.Text, @"^[0-9]+$") && txbox.Text.Length < 5)
            {
                int[] iii = (int[])(txbox.Parent as Grid).DataContext;
                var val = Convert.ToInt32(txbox.Text);
                iii[2] = val;
                GR.AddArrow(iii[0], iii[1], val);
                foreach(var obj in Vertexes.Children)
                {
                    var test = (obj as Grid).DataContext as int[];
                    if(test[1] == iii[0] && test[0] == iii[1])
                    {
                        GR.AddArrow(iii[1], iii[0], val);
                        test[2] = val;
                        return;
                    }
                }
                
            }
            txbox.Text = "0";           
            
        }

        private void BalanceVertex(TextBlock e, Point b)
        {
            foreach (var obj in Vertexes.Children)
            {
                var way = (obj as Grid).DataContext as int[];
                if (e != null)
                {
                    var param = false;
                    if ((((obj as Grid).Children[0] as Path).Data as GeometryGroup).Children.Count == 3)
                        param = true;
                    if (way[1] == Convert.ToInt32(e.Text))
                        MovingVertex(b, obj as Grid, 0, param);
                    if (way[0] == Convert.ToInt32(e.Text))
                        MovingVertex(b, obj as Grid, 1, param);
                }

            }
        }
        private Geometry Arrow(
            double startX,
            double startY,
            double endX,
            double endY,
            double len = 25,
            double width = 5)
        {
            var aaa = (startX - endX);
            var bbb = (startY - endY);
            var ccc = Math.Sqrt(aaa * aaa + bbb * bbb);

            var ad = new Point(
                aaa * VerticeRadius /  ccc,
                bbb * VerticeRadius / ccc);
            
            endX +=  ad.X;
            endY +=  ad.Y;

            var v = new Vector(endX - startX, endY - startY);
            v.Normalize();
            var v1 = new Vector(endX  - v.X * len , endY - v.Y * len);
            var n1 = new Vector(-v.Y * width / 2 + v1.X , v.X * width / 2 + v1.Y );
            var n2 = new Vector(v.Y * width / 2 + v1.X, -v.X * width / 2 + v1.Y);
            var gg = new GeometryGroup();
            gg.Children.Add(new LineGeometry(new Point(n1.X, n1.Y), new Point(endX, endY)));
            gg.Children.Add(new LineGeometry(new Point(n2.X, n2.Y), new Point(endX, endY)));
            return gg;
        }

    }
}
