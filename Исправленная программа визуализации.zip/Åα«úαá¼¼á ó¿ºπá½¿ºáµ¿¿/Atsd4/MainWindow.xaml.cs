﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;

namespace Atsd4
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    
    public partial class MainWindow : Window
    {
        
        Canvas Vertexes { set; get; }
        Canvas Vertices { set; get; }
        int Steps { set; get; } = -1;
        int PosFindway = -1;

        bool IsMoving = false;

        Thread algoProc { set; get; }
        ManualResetEventSlim suspend = new ManualResetEventSlim(true);
        static Graph GR { set; get; }
        VisualModel VM { set; get; }

        int Pos { set; get; }
        
        public MainWindow()
        {
            InitializeComponent();
            Vertexes = Vertex;
            Vertices = Vertice;
            GR = new Graph(Matr);
            VM = new VisualModel(Vertex, Vertice, GR) {
                AddVerticeParametr = AddVerticeParam,
                DeleteParam = DelParam,
                MoveParam = MoveParam,
                Finish = FinishPos,
                Start = StartPos,
                MutexOne = suspend,
                dArr = DArray
            };
            MouseLeftButtonDown += VM.Vertice_Action;
            MouseLeftButtonDown += VM.Verice_StartMove;
            MouseLeftButtonDown += MainWindow_MouseLeftButtonDown;
            MouseMove += VM.Vertice_Moving;
            MouseLeftButtonUp += VM.Vertice_FinishMove;
            MouseLeftButtonUp += MainWindow_MouseLeftButtonUp;
            MouseRightButtonDown += VM.Vertex_Start;
            MouseMove += VM.Moving_Vertex;
            MouseRightButtonUp += VM.Vertex_Finish;
            MouseDoubleClick += VM.Clear_Smth;
            DataContext = GR;
            Closing += MainWindow_Closing;

            
        }

        private void MainWindow_MouseLeftButtonUp(object sender, MouseButtonEventArgs e) {
            IsMoving = false;
            MouseMove -= MainWindow_MouseMove;
        }

        private void MainWindow_MouseLeftButtonDown(object sender, MouseButtonEventArgs e) {
            if (e.Source as Border != null) {
                IsMoving = true;
                MouseMove += MainWindow_MouseMove;
            }
        }

        private void MainWindow_MouseMove(object sender, MouseEventArgs e) {
            if (IsMoving == true ) {
                var pos = e.GetPosition(Main);
                Canvas.SetTop(PanelCon,  pos.Y + 75);
                Canvas.SetLeft(PanelCon,  pos.X - 30);

            }
        }

        private void MainWindow_Closing(object sender, System.ComponentModel.CancelEventArgs e) {
            if (algoProc != null) {
                VM.MutexOne.Set();
                algoProc.Abort();
            }
        }

        private void DoDeikstra(object sender, RoutedEventArgs e)
        {
            if (PosFindway == -1 && VM.FinishPoint != null && VM.FirstPoint != null) {
                startAlgo();
                MoveParam.IsChecked = true;
                GraphPanel.IsEnabled = false;
                (PanelCon.Child as Grid).IsEnabled = true;
                MouseRightButtonDown -= VM.Vertex_Start;
            }
            
                
        }
        
        private void startAlgo() {
            if (VM.FirstPoint == null || VM.FinishPoint == null) {
                return;
            }
            if (PosFindway == - 1 && int.TryParse((VM.FirstPoint.Children[1] as TextBlock).Text, out int st) &&
                int.TryParse((VM.FinishPoint.Children[1] as TextBlock).Text, out int fn)
                ) 
            {
                ResArr.ItemsSource = null;
                var checkk = GR.FindWay(st, fn);
                if (checkk.Count == 1)
                    ResArr.ItemsSource = new List<object> {"No", "way" };
                else {
                    ResArr.ItemsSource = checkk;
                }
                progBar.Maximum = GR.MarkingStep.Count;
                algoProc = new Thread(DoAlgo) { Name = "auto" };
                VM.MutexOne.Set();
                algoProc.Start();

            } else { return; }
            
        }

        private void DoAlgo() {
            
            while (PosFindway + 1 < GR.MarkingStep.Count) {
                VM.MarkingFind(++PosFindway, 0);
                progBar.Dispatcher.Invoke(new Action(() => { progBar.Value = PosFindway + 1; }));
            }
            CloseAlgo();
            
        }
        void CloseAlgo() {
            PosFindway = -1;
            PanelCon.Dispatcher.Invoke(
                new Action(() => {
                    progBar.Value = 0;
                    Next.IsEnabled = false;
                    Back.IsEnabled = false;
                    string a = AppDomain.CurrentDomain.BaseDirectory;
                    for (int i = 0; i < 3; ++i) {
                        a = System.IO.Path.GetDirectoryName(a);
                    }
                    (PausResume.Content as Image).Source = new BitmapImage(new Uri(a + "/img/Pause.png"));
                }));
            Main.Dispatcher.Invoke(new Action(() => { VM.RefreshVertice(); }));
            GraphPanel.Dispatcher.Invoke(new Action(() => {
                GraphPanel.IsEnabled = true;
            }));
            VM.PrevVersion = null;
            MouseRightButtonDown += VM.Vertex_Start;
            PanelCon.Dispatcher.Invoke(new Action(() => { (PanelCon.Child as Grid).IsEnabled = false; }));
        }

        private void NexBtn(object sender, RoutedEventArgs e) {
            if (PosFindway == -1) {
                startAlgo();
            }
            else {
                if (PosFindway + 2 > GR.MarkingStep.Count) {
                    Next.IsEnabled = false;
                }
                VM.MarkingFind(++PosFindway, 0, 1);
                progBar.Value = PosFindway + 1;
                Back.IsEnabled = true;
            }
            
        }

        private void BackBtn(object sender, RoutedEventArgs e) {
            if (PosFindway == 1) {
                (sender as Button).IsEnabled = false;
            }
            VM.MarkingFind(--PosFindway, 1, 1);
            progBar.Value = PosFindway + 1;
            Next.IsEnabled = true;
        }
        private void StopAlgoBtn(object sender, RoutedEventArgs e) {
            CloseAlgo();
        }
        private void StopBtn(object sender, RoutedEventArgs e) {
            string a = AppDomain.CurrentDomain.BaseDirectory;
            for (int i = 0; i < 3; ++i) {
                a = System.IO.Path.GetDirectoryName(a);
            }
             
            
            if (suspend.IsSet) {

                suspend.Reset();
                ((sender as Button).Content as Image).Source = new BitmapImage(new Uri(a +"/img/play.png"));
                

            } else {
                suspend.Set();
                ((sender as Button).Content as Image).Source = new BitmapImage(new Uri(a + "/img/Pause.png"));
                Next.IsEnabled = true;
                Back.IsEnabled = true;
            }
            if (VM.FirstPoint == null || VM.FinishPoint == null) {
                return;
            }
            if (algoProc == null || !algoProc.IsAlive) {
                Next.IsEnabled = true;
                ((sender as Button).Content as Image).Source = new BitmapImage(new Uri(a + "/img/Pause.png"));
                Back.IsEnabled = true;
                startAlgo();
            }
            
        }

        private void TextBlock_MouseDown(object sender, MouseButtonEventArgs e) {
            VisualArray.Visibility = Visibility.Visible;
        }

        private void TextBlock_MouseDown_1(object sender, MouseButtonEventArgs e) {
            VisualArray.Visibility = Visibility.Collapsed;
        }

        private void clRules(object sender, RoutedEventArgs e) {
            Rules a = new Rules();
            a.Show();
        }
    }
}
