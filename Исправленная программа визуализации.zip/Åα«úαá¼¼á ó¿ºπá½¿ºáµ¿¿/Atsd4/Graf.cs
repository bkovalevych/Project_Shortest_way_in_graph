﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows.Controls;
using System.Windows.Media;

namespace Atsd4
{
    public class Graph
    {
        public List<List<int[]>> DeikstraMarks { set; get; }
        public List<int> DeikstraNextPos { set; get; }
        List<int> topPoints;
        public Dictionary<int, int> TopPoints { get {
                topPoints = TopSort();
                Dictionary<int, int> res = new Dictionary<int, int>();
                for (int i = 0; i < topPoints.Count; ++i) {
                    res[topPoints[i]] = i;
                }

                return res;
            }
        }
        public List<int> topp { get {
                topPoints = TopSort();
                return topPoints;
            } }
        public List<List<int[]>> MarkingStep { set; get; } 

        
        public List<List<int[]>> Matches { set; get; }
        
        public ListBox Mat { set; get; }
        public List<int> Index { get {
                var a = new List<int>();
                for (int i = 0; i < Matches.Count; i++)
                    a.Add(i);
                return a;
            } }
        public Graph(ListBox Matr)
        {
           
            Matches = new List<List<int[]>>();
            Mat = Matr;
        }
        public void AddElem(int index)
        {
            Matches.Add(new List<int[]>());
            var st1 = new StackPanel() { Orientation = Orientation.Horizontal };
            st1.Children.Add(new TextBlock { Text = $"{index} " });
            Mat.Items.Add(st1);
        }
        private void RefreshMat()
        {
            for(int i = 0; i < Mat.Items.Count; i++)
            {
                var st = Mat.Items[i];
                ((st as StackPanel).Children[0] as TextBlock).Text = $"{i}";
            }
        }
        public void RemoveItem(int index)
        {
            
            for(int i = 0; i < Matches.Count; i++)
                for(int j = 0; j < Matches[i].Count; j++) {
                    if (Matches[i][j][0] == index) {
                        Matches[i].RemoveAt(j);
                        (Mat.Items[i] as StackPanel).Children.RemoveAt(j + 1);
                        j--;
                    }
                    else if (Matches[i][j][0] > index) {
                        --Matches[i][j][0];
                    }
                }
                    

            Matches.RemoveAt(index);
            Mat.Items.RemoveAt(index);
            RefreshMat();
        }
        
        public void RemoveArrow(int start, int finish)
        {
            
            for(int i = 0; i < Matches[start].Count; i++)
            {
                if(Matches[start][i][0] == finish)
                {
                    Matches[start].RemoveAt(i);
                    (Mat.Items[start] as StackPanel).Children.RemoveAt(i + 1);
                    break;
                }
            }
            for (int i = 0; i < Matches[finish].Count; i++)
            {
                if (Matches[finish][i][0] == start)
                {
                    Matches[finish].RemoveAt(i);
                    (Mat.Items[finish] as StackPanel).Children.RemoveAt(i + 1);
                    return;
                }
            }


        }
        private void Looking(int start, int finish, int val)
        {
            for (int i = 0; i < Matches[start].Count; i++)
            {
                var a = Matches[start][i];
                if (a[0] == finish)
                {
                    a[1] = val;
                    var s1 = (Mat.Items[start] as StackPanel);
                    var s2 = s1.Children[i + 1] as StackPanel;

                    var s3 = s2.Children[1] as TextBlock;
                    s3.Text = $"Вес {val}";
                    return;
                }
            }
        }
        public void AddArrow(int start, int finish, int val = 0)
        {
            if (val != 0)
            {
                Looking(start, finish, val);
                Looking(finish, start, val);
            }
            if (Matches == null || Matches.Count <= start || start < 0)
                return;
            foreach (int[] line in Matches[start])
            {
                if (line[0] == finish)
                    return;
            }
            
            
            Matches[start].Add(new int[] { finish, val });
            
            foreach (int[] line in Matches[finish])
            {
                if (line[0] == start)
                {
                    int pos = -1;
                    for (int i = 0; i < Matches[start].Count; i++)
                        if (Matches[start][i][0] == finish && Matches[start][i][1] > 0)
                            pos = i;
                    if (pos >= 0)
                        Matches[start][pos][1] = line[1];
                }
            }
            var st2 = new StackPanel() { Background = Brushes.LightYellow, Margin = new Thickness(5,0,5,0)};
            st2.Children.Add(new TextBlock() { Text = $"Вершина {finish} ", Background = Brushes.LightCoral });
            st2.Children.Add(new TextBlock() { Text = $"Вес {val} ", Background = Brushes.LightPink });
            (Mat.Items[start] as StackPanel).Children.Add(st2);
            
        }

      
        public void Dfs(int i, ref bool[] visited, ref List<int> points) {
            visited[i] = true;
            for (int j = 0; j < Matches[i].Count; ++j) {
                int v1 = Matches[i][j][0];
                if (!visited[v1]) {
                    Dfs(v1, ref visited, ref points);
                }
            }
            points.Add(i);
        }

        List<int> TopSort() {
            bool[] visited = new bool[Matches.Count];
            List<int> points = new List<int>();
            for (int i = 0; i < Matches.Count; ++i) {
                if (!visited[i]) {
                    Dfs(i, ref visited, ref points);
                }
            }
            points.Reverse();
            return points;
        }

        public List<int> FindWay(int u, int k) {
            MarkingStep = new List<List<int[]>>();
            List<int> d = new List<int>();
            List<int> prev = new List<int>();
            int size = Matches.Count;
            for (int i = 0; i < size; ++i) {
                d.Add(10000000);
                prev.Add(0);
            }
            prev[u] = -1;
            d[u] = 0;
            var points = TopSort();
            foreach (int i in points) {
                MarkingStep.Add(new List<int[]>() { new int[] {i, d[i]} });
                foreach(int[] w in Matches[i]) {
                    if (d[w[0]] > d[i] + w[1]) {
                        prev[w[0]] = i;
                        d[w[0]] = d[i] + w[1];
                    }
                    MarkingStep[MarkingStep.Count - 1].Add(new int[] { w[0], d[w[0]] });
                }
            }
            int pos = k;
            List<int> Way = new List<int>();
            if (d[k] >= 10000000) {
                Way.Add(-1);
            } else
            while (pos != -1) {
                Way.Add(pos);
                pos = prev[pos];
            }
            
            Way.Reverse();
            return Way;
        }
        
        public void Deikstra(object po)
        {
            DeikstraNextPos = new List<int>();
            DeikstraMarks = new List<List<int[]>>();
            var pos = Convert.ToInt32(po);
            int[] Points = new int[Matches.Count];
            for (int i = 0; i < Points.Length; i++)
            {
                Points[i] = 1000000;
            }
            Points[pos] = 0;
            bool[] CheckedVertices = new bool[Points.Length];
            while (pos != -1)
            {
                pos = SetNextPos(Points, pos, CheckedVertices);
                DeikstraNextPos.Add(pos);
            }
            
            
        }
        private int SetNextPos(int[] Points, int pos, bool[] CheckedVertices)
        {
            DeikstraMarks.Add(new List<int[]>());
            int res = -1;
            int min = 100000;
            bool checkMin = false;
            foreach (int[] futureVertice in Matches[pos])
            {

                if (!CheckedVertices[futureVertice[0]])
                {
                    if (!checkMin)
                        res = futureVertice[0];
                    if (futureVertice[1] < min)
                    {
                        checkMin = true;
                        res = futureVertice[0];
                        min = futureVertice[1];
                    }
                    if (futureVertice[1] + Points[pos] < Points[futureVertice[0]])
                    {
                        var a = futureVertice[1] + Points[pos];
                        Points[futureVertice[0]] = a;
                        DeikstraMarks[DeikstraMarks.Count - 1].Add(new int[] { futureVertice[0], a });
                    }

                }
            }
            CheckedVertices[pos] = true;
            for(int i = 0; i < Points.Length; i++)
            {
                if (!CheckedVertices[i] && Points[pos] >= Points[i])
                    res = i;
            }
            if(res == -1)
                for(int i = 0; i < CheckedVertices.Length; i++)
                    if(!CheckedVertices[i])
                    {
                        res = i;
                        break;
                    }
            
            OnMarkingVertice?.Invoke(Points, res);
            return res;
        }

        public delegate void VerticeEvent(int[] Points, int NextMark);
        public event VerticeEvent OnMarkingVertice;
        
    }
}
